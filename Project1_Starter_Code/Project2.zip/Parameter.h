//
// Created by john stewart on 10/6/22.
//

#ifndef PROJECT1_STARTER_CODE_PARAMETER_H
#define PROJECT1_STARTER_CODE_PARAMETER_H
#include <string>
using namespace std;

class Parameter {
public:
    void setContent(string);
    string returnContent();
private:
    std::string content;
};


#endif //PROJECT1_STARTER_CODE_PARAMETER_H
