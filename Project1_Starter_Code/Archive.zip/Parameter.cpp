//
// Created by john stewart on 10/6/22.
//

#include "Parameter.h"
#include <string>

void Parameter::setContent(string newContent) {
    content = newContent;
}
string Parameter::returnContent(){
    return content;
}

